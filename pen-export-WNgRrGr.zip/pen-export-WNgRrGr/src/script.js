function myFunction(){
  // alert("Thanks for visiting !!")
  let header=
      (document.getElementById("header").style.color="blue");
}